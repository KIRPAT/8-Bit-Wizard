Arduino Joystick
================

How does it work?
-----------------
Using 'Serial.print()' we can output a message, we can read this message in Unity and parse it to floats.

How do you use it?
------------------
1. Add the Arduino.cs to your Unity Project.
2. Upload the Arduino script to your Arduino.
3. Connect the Arduino to your PC.
4. In the Arduino.cs edit the com-port to the port you've connected your Arduino.